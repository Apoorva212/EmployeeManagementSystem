package com.sakha.service;

import com.sakha.employeedao.EmployeeDao;
import com.sakha.employeedao.EmployeeDaoImplementation;
import com.sakha.model.Employee;

public class GetEmployeeService {
	EmployeeDao dao=new EmployeeDaoImplementation();
 public Employee getEmployee(String empid) throws Exception
 {
	 return dao.getEmp(empid);
 }
}
