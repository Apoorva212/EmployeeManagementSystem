package com.sakha.service;

import java.util.List;

import com.sakha.employeedao.EmployeeDao;
import com.sakha.employeedao.EmployeeDaoImplementation;
import com.sakha.model.Employee;

public class GetAllEmployeeService {
	EmployeeDao dao=new EmployeeDaoImplementation();
	public List<Employee>getAllEmployee() throws Exception
	
	{
		return dao.getAllEmployee();
	}
}