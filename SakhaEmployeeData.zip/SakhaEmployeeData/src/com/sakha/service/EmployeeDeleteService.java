package com.sakha.service;

import com.sakha.employeedao.EmployeeDao;
import com.sakha.employeedao.EmployeeDaoImplementation;

public class EmployeeDeleteService {
	EmployeeDao dao=new EmployeeDaoImplementation();
public boolean delete(String empid) throws Exception {
	return dao.deleteEmployee(empid);
}
}
