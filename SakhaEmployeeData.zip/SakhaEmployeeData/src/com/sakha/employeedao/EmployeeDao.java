package com.sakha.employeedao;

import java.sql.Connection;
import java.util.List;

import com.sakha.model.Employee;

public interface EmployeeDao {
	public boolean addEmployee(Employee e)throws Exception ;
	public Connection getConnection() throws Exception;
	public String generatedId(String empname) throws Exception; 
	public boolean deleteEmployee(String empid)throws Exception;
	public Employee getEmp(String empid) throws Exception;
	public List<Employee> getAllEmployee() throws Exception;
	public boolean updateEmp(String empid, float salary) throws Exception;
}
